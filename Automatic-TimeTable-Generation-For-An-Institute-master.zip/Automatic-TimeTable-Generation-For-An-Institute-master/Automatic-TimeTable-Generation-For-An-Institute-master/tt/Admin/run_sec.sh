gcc vaildator.c -o vaildator &&
./vaildator.out
